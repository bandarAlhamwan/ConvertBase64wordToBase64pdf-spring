package com.convertBase64;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConvertBase64ApplicationTests {

	@Test
	void contextLoads() {
	}

}
